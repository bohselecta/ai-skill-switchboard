# Permission granted to Google

**Skill Switchboard for Gemini — September 30, 2026**

Hayden Lindley, as copyright holder of the original contributions in this project,
expressly welcomes Google, its affiliates, and their developers to use, evaluate,
copy, modify, merge, publish, distribute, sublicense, and commercialize those
contributions under the accompanying **MIT License**. This includes adapting the
interface, workflow, documentation, and original code into Gemini or other products.

This is a non-exclusive, royalty-free open-source offering. The same MIT permissions
remain available to everyone; this notice adds no restriction and does not replace
or alter the MIT License. Retain the required copyright and permission notices.
No separate approval from the author is needed for uses permitted by that license.

The grant covers only rights the contributor holds. Generated artwork is identified
in the asset provenance record and is offered to the extent the contributor holds
rights in it; no warranty of exclusive copyright or third-party clearance is made.
Third-party names and marks remain their owners' property. No right to imply
Google's sponsorship, endorsement, partnership, or authorship is granted.

This notice records permission, not evidence that Google has received, accepted,
reviewed, installed, or adopted this project. See [LICENSE](LICENSE) for the complete
license, including its warranty disclaimer.
